#!/usr/bin/env python3
"""Bridge FFmpeg Rockchip's RKMPP device to mpv's existing DMA-BUF mapper."""
from pathlib import Path
import hashlib
import json

work = Path(__file__).resolve().parent
root = work / 'src/mpv'
changed = {}

def edit(name, transform):
    p = root / name
    before = p.read_text()
    after = transform(before)
    if before != after:
        changed[name] = {'before': hashlib.sha256(before.encode()).hexdigest(),
                         'after': hashlib.sha256(after.encode()).hexdigest()}
        p.write_text(after)

def meson(text):
    if "features += {'rkmpp':" not in text:
        needle = 'conf_data = configuration_data()'
        assert text.count(needle) == 1
        text = text.replace(needle,
            "features += {'rkmpp': cc.has_header_symbol('libavutil/hwcontext.h', "
            "'AV_HWDEVICE_TYPE_RKMPP', dependencies: libavutil)}\n" + needle)
    return text

def registry(text):
    if 'ra_hwdec_rkmpp' not in text:
        needle = 'extern const struct ra_hwdec_driver ra_hwdec_drmprime;'
        assert text.count(needle) == 1
        text = text.replace(needle, needle + '\n#if HAVE_RKMPP\n'
                            'extern const struct ra_hwdec_driver ra_hwdec_rkmpp;\n#endif')
        needle = '#if HAVE_DRM\n    &ra_hwdec_drmprime,'
        assert text.count(needle) == 1
        text = text.replace(needle, '#if HAVE_DRM\n#if HAVE_RKMPP\n'
                            '    &ra_hwdec_rkmpp,\n#endif\n    &ra_hwdec_drmprime,')
    return text

def mapper(text):
    if 'ra_hwdec_rkmpp' not in text:
        needle = '                                     AV_HWDEVICE_TYPE_DRM,\n                                     device_path, NULL, 0);'
        assert text.count(needle) == 1
        text = text.replace(needle,
            '                                     hw->driver->device_type,\n'
            '                                     hw->driver->device_type == AV_HWDEVICE_TYPE_DRM\n'
            '                                         ? device_path : NULL, NULL, 0);')
        start = text.index('const struct ra_hwdec_driver ra_hwdec_drmprime = {')
        driver = text[start:].strip()
        assert driver.endswith('};')
        rkmpp = driver.replace('ra_hwdec_drmprime', 'ra_hwdec_rkmpp')
        rkmpp = rkmpp.replace('.name = "drmprime"', '.name = "rkmpp-drmprime"')
        rkmpp = rkmpp.replace('AV_HWDEVICE_TYPE_DRM', 'AV_HWDEVICE_TYPE_RKMPP')
        text += '\n#if HAVE_RKMPP\n' + rkmpp + '\n#endif\n'
    return text

edit('meson.build', meson)
edit('video/out/gpu/hwdec.c', registry)
edit('video/out/hwdec/hwdec_drmprime.c', mapper)
record = work / 'mpv-adaptation.json'
if changed:
    record.write_text(json.dumps({'purpose': 'RKMPP hardware device interoperability with existing DRM PRIME DMA-BUF mapper',
                                  'upstream': 'mpv v0.42.0', 'files': changed}, indent=2) + '\n')
assert record.is_file()
print(record.read_text())
